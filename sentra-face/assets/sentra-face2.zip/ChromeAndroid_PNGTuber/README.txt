Chrome Android PNGTuber pack
=============================

4-state PNGTuber based on your chrome / iridescent android portrait.
Canvas: 1152 x 1648 PNG with transparent background.
Bottom edge is a straight crop across both shoulders.

Files
-----
idle.png        mouth closed, eyes open
talk.png        mouth open,  eyes open
blink.png       mouth closed, eyes closed
talk_blink.png  mouth open,  eyes closed

Veadotube Mini
--------------
1. Download: https://olmewe.itch.io/veadotube-mini
2. New Neutral state
3. Assign the four PNGs to the matching mouth/eye slots
4. Background: Transparent
5. OBS: Game Capture of veadotube mini + Allow Transparency
